# 🌌 Space Elevator

An interactive website that takes the user on a journey through the scales
of the Universe — from the quantum foam smaller than an atom, up through
Earth, the Solar System, and the Milky Way, out to the observable Universe
and beyond. Built for the Ashlesha Astronomy Club Web Development task.

## How it works

- **Elevator lobby (front page):** an elevator car with a floor panel.
  Each floor is a level, ordered by scale — `B2` (smallest) up to `PH`
  (largest). Picking a floor plays a full elevator ride: doors close, the
  floor indicator counts through each floor in between, then the doors
  open on that level.
- **7 levels**, each with a title, a circular photo/visual, and 1–2 facts:
  Quantum Foam, Micro World, Earth, Solar System, Milky Way, Universe,
  Multiverse.
- **Navigation:** swipe, the on-screen ◀ PREV / NEXT ▶ buttons, the
  progress dots, or the ← → arrow keys. A 🛗 button in the header returns
  to the elevator lobby at any time (with the same door animation).
- **Interactive level photos:** click once on a level's photo and it
  zooms in and follows your mouse as you move over it; click again to
  reset. On touch devices, pinch with two fingers to zoom, all clipped to
  the circle.
- **Clickable planets:** the Solar System level has all 8 planets — tap
  one for its name and a fact.
- **Mini astronomy quiz:** a 4-question quiz on the Universe level, with
  live scoring and sound feedback.
- **Random Cosmic Fact button (✨):** pulls a random bonus fact into a
  toast popup.
- **Sound effects:** short synthesized tones (Web Audio API, no audio
  files needed) for navigation, floor travel, planet taps, and quiz
  answers — with a mute toggle (🔊/🔇) that's remembered between visits.
- **Animated starfield background**, including the occasional shooting
  star.

## Technologies used

- **HTML5** — page structure (`index.html`)
- **CSS3** — all styling, animations and layout (`css/style.css`);
  no framework, no build step
- **Vanilla JavaScript (ES6)** — all interactivity (`js/script.js`);
  no libraries or dependencies
- **Web Audio API** — generated sound effects
- **Canvas API** — the starfield background
- **Google Fonts** — Orbitron (headings/UI) and Rubik (body text)

No AI-generated code beyond this project's own assistant-guided
development was used for astronomy facts — all facts were written and
fact-checked by hand.

## Project structure

```
space-elevator/
├── index.html          # page structure
├── css/
│   └── style.css        # all styling
├── js/
│   └── script.js        # all behaviour/interactivity
├── images/               # optional real photos (see images/README.md)
│   └── README.md
└── README.md             # this file
```

## Running it

No build step or server required.

1. Unzip the project.
2. Open `index.html` directly in any modern browser (double-click it, or
   right-click → Open With → your browser).

To host it (e.g. GitHub Pages): push the folder to a repo and enable
Pages on the `main` branch / root folder — `index.html` will be served
automatically.

## Adding real photos (optional)

The site works out of the box with themed emoji for every level. To swap
in real photos, see `images/README.md` for the exact file names expected
and some free image sources.
